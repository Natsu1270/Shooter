import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  uri = 'http://localhost:8080/user';

  constructor(private http: HttpClient) { }

  test(name, email) {
    console.log(name);
    console.log(email);
  }

  addUser(name, email) {
    const obj = {
      name : name,
      email : email
    };
    console.log(obj);
    this.http.post(`${this.uri}/add`, obj)
        .subscribe(res => console.log('Add done'))
  }

  getUsers() {
    return this
          .http
          .get(`${this.uri}`)
  }
}
