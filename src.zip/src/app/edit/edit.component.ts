import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  angForm: FormGroup;

  constructor(private fb: FormBuilder) { this.createForm() }

  createForm() {
    this.angForm = this.fb.group({
      person_name: ['', Validators.required],
      business_name: ['', Validators.required ],
      business_gst_number: ['', Validators.required ]
    })
  }

  ngOnInit() {
  }


}
