import User from './User';
import { Time } from '@angular/common';

export default class Note {
    user: User;
    content: String;
    createdDate: Time;
}