export default class User {
    name: String;
    email: String;
}