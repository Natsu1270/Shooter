import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './list/list.component';
import { EditComponent } from './edit/edit.component';
import { AddComponent } from './add/add.component';
import { NgxSpinnerModule } from "ngx-spinner";
const routes: Routes = [
  {
    path: 'user/create',
    component: AddComponent
  },
  {
    path: 'user/edit',
    component: EditComponent
  },
  {
    path: 'user/list',
    component: ListComponent
  }

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
    NgxSpinnerModule
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
