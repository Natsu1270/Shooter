import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {


  angForm: FormGroup;

  constructor(private fb: FormBuilder, private us: UserService) { this.createForm() }

  createForm() {
    this.angForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required ],
    })
  }

  addUser(name, email) {
    this.us.addUser(name, email);
  }

  ngOnInit() {
  }

}
