import { Component } from '@angular/core';
import { NgxSpinnerService } from "ngx-spinner";
import { NavigationCancel,
  Event,
  NavigationEnd,
  NavigationError,
  NavigationStart,
  Router } from '@angular/router';
  

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BookManager';
  constructor(private _loadingBar: NgxSpinnerService, private _router: Router) {
    this._router.events.subscribe((event: Event) => {
      this.navigationInterceptor(event);
    });
  }
  private navigationInterceptor(event: Event): void {
    if (event instanceof NavigationStart) {
      this._loadingBar.show();
    }
    if (event instanceof NavigationEnd) {
      this._loadingBar.hide();
    }
    if (event instanceof NavigationCancel) {
      this._loadingBar.hide();
    }
    if (event instanceof NavigationError) {
      this._loadingBar.hide();
    }
  }
}
